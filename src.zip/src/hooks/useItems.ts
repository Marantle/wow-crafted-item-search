import { useState, useEffect } from "react";
import { CraftedItem } from "@/types/craftingTypes";
import { craftedItemsData } from "@/data/craftedItems"; // Adjust this import path if necessary

export function useItems() {
  const [items, setItems] = useState<CraftedItem[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    try {
      setItems(craftedItemsData);
      setLoading(false);
    } catch (err) {
      setError("An error occurred while loading the items");
      setLoading(false);
    }
  }, []);

  return { items, loading, error };
}

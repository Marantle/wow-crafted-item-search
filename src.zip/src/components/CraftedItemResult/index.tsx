import { useRef, useState } from 'react'
import { Card, CardContent } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Separator } from "@/components/ui/separator"
import { Heart, Scale } from "lucide-react"
import { CraftedItem } from '@/types/craftingTypes'
import ItemHeader from './ItemHeader'
import ItemBadges from './ItemBadges'
import MaterialsList from './MaterialsList'

interface CraftedItemResultProps {
  item: CraftedItem
  onToggleFavorite: (itemId: number) => void
  onToggleCompare: (itemId: number) => void
  isFavorite: boolean
  isComparing: boolean
}

export default function CraftedItemResult({ 
  item, 
  onToggleFavorite, 
  onToggleCompare, 
  isFavorite, 
  isComparing 
}: CraftedItemResultProps) {
  const titleRef = useRef<HTMLHeadingElement>(null)
  const [materialRefs, setMaterialRefs] = useState<(HTMLSpanElement | null)[]>([])

  return (
    <Card className="mb-4">
      <CardContent className="pt-6">
        <div className="flex justify-between items-start mb-4">
          <ItemHeader 
            name={item.name} 
            crafter={item.crafter} 
            realm={item.realm} 
            titleRef={titleRef}
          />
          <div className="flex space-x-2">
            <Button
              variant="outline"
              size="icon"
              onClick={() => onToggleFavorite(item.id)}
              aria-label={isFavorite ? "Remove from favorites" : "Add to favorites"}
            >
              <Heart className={`h-4 w-4 ${isFavorite ? "fill-red-500" : ""}`} />
            </Button>
            <Button
              variant="outline"
              size="icon"
              onClick={() => onToggleCompare(item.id)}
              aria-label={isComparing ? "Remove from comparison" : "Add to comparison"}
            >
              <Scale className={`h-4 w-4 ${isComparing ? "text-blue-500" : ""}`} />
            </Button>
          </div>
        </div>
        <ItemBadges 
          itemLevel={item.itemLevel}
          embellishedQuality={item.embellishedQuality}
          missiveQuality={item.missiveQuality}
          concentrate={item.concentrate}
          skillBooster={item.skillBoosterId ? { id: item.skillBoosterId, name: '', shortName: '', skillBonus: 0, wowheadLink: '' } : undefined}
          tags={item.tags}
        />
        <Separator className="my-4" />
        <h3 className="text-lg sm:text-xl font-semibold mb-2">Required Materials</h3>
        <MaterialsList 
          materials={item.materials} 
          truncatedMaterials={[]}
          materialRefs={materialRefs}
        />
      </CardContent>
    </Card>
  )
}
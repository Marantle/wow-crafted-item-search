"use client";

import { useState, useMemo } from "react";
import {
  Command,
  CommandEmpty,
  CommandGroup,
  CommandInput,
  CommandItem,
  CommandList,
} from "@/components/ui/command";
import CraftedItemResult from "./CraftedItemResult";
import ComparisonTool from "./ComparisonTool";
import { CraftedItem } from "@/types/craftingTypes";
import { useItems } from "@/hooks/useItems";

export default function WowCraftingSearch() {
  const { items, loading, error } = useItems();
  const [searchTerm, setSearchTerm] = useState("");
  const [favorites, setFavorites] = useState<number[]>([]);
  const [comparing, setComparing] = useState<number[]>([]);
  const [showCommandList, setShowCommandList] = useState(false);

  const filteredItems = useMemo(() => {
    if (!items) return [];
    return items.filter(
      (item) =>
        item.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
        item.crafter.toLowerCase().includes(searchTerm.toLowerCase()) ||
        item.tags.some((tag) =>
          tag.toLowerCase().includes(searchTerm.toLowerCase())
        )
    );
  }, [items, searchTerm]);

  const autocompleteItems = useMemo(() => {
    if (!items) return [];
    return items
      .filter(
        (item) =>
          item.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
          item.crafter.toLowerCase().includes(searchTerm.toLowerCase()) ||
          item.tags.some((tag) =>
            tag.toLowerCase().includes(searchTerm.toLowerCase())
          )
      )
      .slice(0, 5);
  }, [items, searchTerm]);

  const toggleFavorite = (itemId: number) => {
    setFavorites((prev) =>
      prev.includes(itemId)
        ? prev.filter((id) => id !== itemId)
        : [...prev, itemId]
    );
  };

  const toggleCompare = (itemId: number) => {
    setComparing((prev) => {
      if (prev.includes(itemId)) {
        return prev.filter((id) => id !== itemId);
      }
      if (prev.length < 3) {
        return [...prev, itemId];
      }
      return prev;
    });
  };

  const handleSearchChange = (value: string) => {
    setSearchTerm(value);
    setShowCommandList(value.length > 0);
  };

  const handleItemSelect = (itemName: string) => {
    setSearchTerm(itemName);
    setShowCommandList(false);
  };

  if (loading) {
    return <div>Loading...</div>;
  }

  if (error) {
    return <div>Error: {error}</div>;
  }

  if (!items) {
    return <div>No items available.</div>;
  }

  return (
    <div className="w-full max-w-4xl mx-auto">
      <h1 className="text-3xl font-bold mb-6">WoW Crafted Items</h1>
      <div className="relative mb-4">
        <Command>
          <CommandInput
            placeholder="Search items by name, crafter, or tags..."
            value={searchTerm}
            onValueChange={handleSearchChange}
          />
          {showCommandList && (
            <CommandList>
              <CommandEmpty>No items found.</CommandEmpty>
              <CommandGroup>
                {autocompleteItems.map((item) => (
                  <CommandItem
                    key={item.id}
                    onSelect={() => handleItemSelect(item.name)}
                  >
                    <div>
                      <div>{item.name}</div>
                      <div className="text-sm text-muted-foreground">
                        Tags: {item.tags.join(", ")}
                      </div>
                    </div>
                  </CommandItem>
                ))}
              </CommandGroup>
            </CommandList>
          )}
        </Command>
      </div>
      <ComparisonTool
        items={items.filter((item) => comparing.includes(item.id))}
        onRemoveItem={(itemId) => toggleCompare(itemId)}
      />
      <div className="mt-8">
        {filteredItems.map((item) => (
          <CraftedItemResult
            key={item.id}
            item={item}
            onToggleFavorite={toggleFavorite}
            onToggleCompare={toggleCompare}
            isFavorite={favorites.includes(item.id)}
            isComparing={comparing.includes(item.id)}
          />
        ))}
      </div>
      {filteredItems.length === 0 && (
        <p className="text-center text-gray-500 mt-4">
          No items found matching your search.
        </p>
      )}
    </div>
  );
}
